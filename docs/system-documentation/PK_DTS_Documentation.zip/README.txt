PK DOCUMENT TRACKING SYSTEM - PROPOSED DOCUMENTATION
26 OCTOBER 2026 | REVISION 02 | PROPOSAL

Proposed Process Flow: editable Visio (.vsdx) and PDF, five sheets.
Data Flow Diagram: PDF, two participant and system sheets.
Flowchart: editable Visio (.vsdx) and PDF, six sheets.
Proposed User Guide: PowerPoint (.pptx) and PDF, with screen
illustrations, sample data and nine request scenarios.

The documents define intended processes and user procedures.
Diagram headings, cards, arrows and notes use Peanut Kisses red.
Screen illustrations use sample accounts, records and transactions.
The published workflow will determine each request's approvers;
available actions will depend on assigned permissions and access.
