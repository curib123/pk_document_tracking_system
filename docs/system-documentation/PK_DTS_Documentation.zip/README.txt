PK DOCUMENT TRACKING SYSTEM - 26 OCTOBER 2026

Proposed Process Flow: editable Visio (.vsdx) and PDF.
Data Flow Diagram: PDF, eight coordinated sheets.
Flowchart: editable Visio (.vsdx) and PDF.
User Guide: PowerPoint (.pptx) with screenshots, editable arrows,
sample data, all nine request walkthroughs, and a PDF reading copy.

The documents describe the implemented system. Screenshots use
synthetic examples; actual access and approvers are configured
for each installation. No passwords are included.

The Visio package structure and connectors were validated; native
Visio opening was unavailable. PowerPoint was opened and exported
using installed Microsoft PowerPoint.

Source models, screenshots, evidence and rebuilding instructions
are in the repository at docs/system-documentation and
tools/documentation.
